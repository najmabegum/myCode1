namespace MVC_SESSION.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;
    using MVC_SESSION.Models;

    internal sealed class Configuration : DbMigrationsConfiguration<MVC_SESSION.Models.RestaurantData>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = true;
            ContextKey = "MVC_SESSION.Models.RestaurantData";
        }

        protected override void Seed(MVC_SESSION.Models.RestaurantData context)
        {

            context.RestaurantLists.AddOrUpdate(
                 p => p.Name,
                 new Restaurant { Name = "Sabatino's", City = "Baltimore", Country = "USA" },
                  new Restaurant { Name = "Great Desert", City = "Chicago", Country = "USA" },
                   new Restaurant { Name = "China Place", City = "LA", Country = "USA" }
               );
            
        }
    }
}

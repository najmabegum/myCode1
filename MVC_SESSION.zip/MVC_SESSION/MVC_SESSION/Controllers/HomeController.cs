﻿using MVC_SESSION.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVC_SESSION.Controllers
{
    public class HomeController : Controller
    {
        RestaurantData _db = new RestaurantData(); 
        // GET: Home
        public ActionResult Index()
        {
            var model = _db.RestaurantLists.ToList();
            return View(model);
        }
    }
}
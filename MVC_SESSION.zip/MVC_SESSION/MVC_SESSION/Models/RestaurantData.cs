﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace MVC_SESSION.Models
{
    public class RestaurantData : DbContext
    {
        public RestaurantData()
            : base("name=DefaultConnection")
    {

    }
        public DbSet<Restaurant> RestaurantLists { get; set; }
    }
}
﻿using mvc_modeldemo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace mvc_modeldemo.Controllers
{
    public class EmployeeController : Controller
    {
      
        // GET: Employee
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult DisplayEmployee()
        {
            Employee emp = new Employee();
            emp.EmpId = 1;
            emp.FirstName = "najma";
            emp.LastName = "begum";

            Employee emp2 = new Employee();
            emp2.EmpId = 2;
            emp2.FirstName = "ankit";
            emp2.LastName = "roy";

            List<Employee> emplist = new List<Employee>();
            emplist.Add(emp);
            emplist.Add(emp2);

           

            return View(emplist);
        }

        public ActionResult DisplayDeptDetails(int id)
        {
        
            Employee emp = new Employee();
            emp.EmpId = 1;
            emp.FirstName = "najma";
            emp.LastName = "begum";
            emp.DeptId = 1;

            Employee emp2 = new Employee();
            emp2.EmpId = 2;
            emp2.FirstName = "ankit";
            emp2.LastName = "roy";
            emp2.DeptId = 2;

             List<Employee> emplist = new List<Employee>();
            emplist.Add(emp);
            emplist.Add(emp2);

            Department dep1 = new Department();
            dep1.DeptId = 1;
            dep1.DeptName = "Development";
            dep1.employeeDetails=emplist;

            Department dep2 = new Department();
            dep2.DeptId = 2;
            dep2.DeptName = "Testing";
            dep2.employeeDetails= emplist;

            var d = 
           return View();
        }
    }
}
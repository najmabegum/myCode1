﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace mvc_modeldemo.Models
{
    public class Employee
    {
        public int EmpId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int DeptId { get; set; }
    }
}
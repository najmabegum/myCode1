﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.IO;

namespace contactport.Controllers
{
    public class ContactController : Controller
    {
        // GET: Contact
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Resume()
        {
           string fileName = "EmployeeDetailsData.pdf";
            FileStream fs = new FileStream(@"C:\Users\mslc\Desktop\EmployeeDetailsCaselet\" + fileName, FileMode.Open, FileAccess.Read);
           
            return View();
        }
        public ActionResult ReturnFile()
        {
            string fileName = "EmployeeDetailsData.pdf";
            FileStream fs = new FileStream(@"C:\Users\mslc\Desktop\EmployeeDetailsCaselet\" + fileName, FileMode.Open, FileAccess.Read);
            return File(fs, "application/pdf", fileName);
            
        }
    }
}
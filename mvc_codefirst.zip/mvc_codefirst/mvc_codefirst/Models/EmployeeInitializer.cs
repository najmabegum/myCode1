﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace mvc_codefirst.Models
{
    public class EmployeeInitializer: DropCreateDatabaseIfModelChanges<EmployeeContext>
    {
        protected override void Seed(EmployeeContext context)
        {
            var employees = new List<Employee>
          {
              new Employee {FirstName="Najma", LastName="Begum"},
              new Employee {FirstName="Ankit", LastName="Roy"}
          };
            foreach(var item in employees)
            {
                context.Employees.Add(item);
            }
            context.SaveChanges();
        }
    }
}
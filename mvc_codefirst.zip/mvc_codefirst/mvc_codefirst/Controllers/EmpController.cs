﻿using mvc_codefirst.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace mvc_codefirst.Controllers
{
    public class EmpController : Controller
    {
        private EmployeeContext _db = new EmployeeContext();
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult DisplayEmployees()
        {
            var employees = _db.Employees.ToList();
            return View(employees);
        }


    }
}
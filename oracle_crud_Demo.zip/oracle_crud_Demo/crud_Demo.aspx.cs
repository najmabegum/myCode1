﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;

public partial class crud_Demo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string strcon = "USER ID=SYSTEM;PASSWORD=system;DATA SOURCE=localhost:1521/XE";
        OracleConnection con = new OracleConnection(strcon);
        OracleCommand cmd = new OracleCommand();
        con.Open();
        cmd.CommandText = "INSERT INTO EMP (@num,@name,@job,@sal,@dept)VALUES(EMPNO,ENAME,JOB,SAL,DEPTNO)";
        OracleParameter pnum = new OracleParameter("@num", TextBoxnum.Text);
        OracleParameter pname = new OracleParameter("@name", TextBoxname.Text);
        OracleParameter pjob = new OracleParameter("@job", TextBoxjob.Text);
        OracleParameter psal = new OracleParameter("@sal", TextBoxsal.Text);
        OracleParameter pdept = new OracleParameter("@dept", TextBoxnum.Text);


        cmd.Parameters.Add(pnum);
        cmd.Parameters.Add(pname);
        cmd.Parameters.Add(pjob);
        cmd.Parameters.Add(psal);
        cmd.Parameters.Add(pdept);

            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            
    }
}